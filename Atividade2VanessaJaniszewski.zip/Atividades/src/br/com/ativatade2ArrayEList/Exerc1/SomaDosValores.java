package br.com.ativatade2ArrayEList.Exerc1;

public class SomaDosValores {
	public static void main(String[] args) {
		
		int[] valores = new int[] {1,3,5,87,12,4,65,3,5};
		int soma =0;
		
		for(int i=0; i<valores.length;i++) {
			soma+=valores[i];}
		
		System.out.println("Soma: "+soma);		
		
	}

}
