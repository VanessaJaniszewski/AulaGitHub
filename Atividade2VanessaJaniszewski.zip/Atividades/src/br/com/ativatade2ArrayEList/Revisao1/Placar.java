package br.com.ativatade2ArrayEList.Revisao1;

import java.util.Scanner;

public class Placar {
	
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		String[] times = new String[2];
		Integer[] pontuacao = new Integer[2];
		
		System.out.println("Nome do primeiro time:");
		times[0]= scanner.next();
		System.out.println("Nome do segundo time:");
		times[1] = scanner.next();
		System.out.println("pontuacao do time "+times[0]+" :");
		pontuacao[0] = scanner.nextInt();
		System.out.println("pontuacao do time "+times[1]+" :");
		pontuacao[1] = scanner.nextInt();
		
		String vencedor;
		if(pontuacao[0]>pontuacao[1]) {
			vencedor= times[0];
		}else if(pontuacao[0]<pontuacao[1]) {
			vencedor = times[1];
		}else {
			vencedor = "empate";
		}
		
		System.out.println("O time vencedor é: "+vencedor);
		
		scanner.close();
		}
	}


