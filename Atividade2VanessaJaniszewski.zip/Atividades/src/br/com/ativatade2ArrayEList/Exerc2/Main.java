package br.com.ativatade2ArrayEList.Exerc2;

import java.util.ArrayList;
import java.util.List;

public class Main {
	public static void main(String[] args) {
		

		List<Cliente> bomPagador = new ArrayList<>();
		List<Cliente> mauPagador = new ArrayList<>();
		
	ListaDevedores d1 = new ListaDevedores("Vanessa",-500.00);
	ListaDevedores d2 = new ListaDevedores("Joao",500.00);
	ListaDevedores d3 = new ListaDevedores("Ana",524.00);
	ListaDevedores d4 = new ListaDevedores("Paula",-48.00);
	ListaDevedores d5 = new ListaDevedores("Andre",-746.00);
	ListaDevedores d6 = new ListaDevedores("Davi",2845.00);
	
//	ListaDevedores.controlePagador(d1);
//	ListaDevedores.controlePagador(d2);
//	ListaDevedores.controlePagador(d3);
//	ListaDevedores.controlePagador(d4);
//	ListaDevedores.controlePagador(d5);
//	ListaDevedores.controlePagador(d6);
	
	
	ListaDevedores.imprimirPagadores();
	
	
	
	
	
	
		
	}
}
