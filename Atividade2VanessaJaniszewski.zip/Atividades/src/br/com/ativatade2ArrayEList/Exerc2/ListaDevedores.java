package br.com.ativatade2ArrayEList.Exerc2;

import java.util.ArrayList;
import java.util.List;

public class ListaDevedores extends Cliente{

	public ListaDevedores(String cliente, double saldo) {
		super(cliente, saldo);
		controlePagador(this);
		// TODO Auto-generated constructor stub
	}

	static List<Cliente> bomPagador = new ArrayList<>();
	static List<Cliente> mauPagador = new ArrayList<>();




	public static void  controlePagador(Cliente nome) {
		if(nome.getSaldo()>=0) {
			bomPagador.add(nome);}
			else {
				mauPagador.add(nome);}}
		
		
	
public static void  imprimirPagadores() {
	for (Cliente cliente : bomPagador) {
		System.out.println("Bom pagador: "+cliente.cliente);}
	for (Cliente cliente : mauPagador) {
		System.out.println("Mau pagador: "+cliente.cliente);
		
	}
	
}}

