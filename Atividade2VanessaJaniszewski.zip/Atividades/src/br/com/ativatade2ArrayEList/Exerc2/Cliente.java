package br.com.ativatade2ArrayEList.Exerc2;

public abstract class Cliente {
	
	String cliente;
	double saldo;
	
	
	public Cliente(String cliente, double saldo) {
		super();
		this.cliente = cliente;
		this.saldo = saldo;
	}

	public String getCliente() {
		return cliente;
	}

	public void setCliente(String cliente) {
		this.cliente = cliente;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}


}
