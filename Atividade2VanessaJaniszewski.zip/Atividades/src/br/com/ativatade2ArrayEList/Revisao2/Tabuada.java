package br.com.ativatade2ArrayEList.Revisao2;

import java.util.Scanner;

public class Tabuada {
	public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);		
	
	Integer[] tabuada = new Integer[] {
			0,1,2,3,4,5,6,7,8,9,10};
	
	System.out.println("De qual número deseja saber a tabuada? ");
	Integer n = scanner.nextInt();
	
	
	for(int i=0; i<tabuada.length; i++) {
	System.out.println(n+" x "+tabuada[i]+" = "+tabuada[i]*n);
	}
	scanner.close();

}
}